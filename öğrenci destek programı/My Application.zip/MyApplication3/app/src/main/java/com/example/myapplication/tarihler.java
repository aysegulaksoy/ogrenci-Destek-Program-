package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.core.view.Event;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class tarihler extends AppCompatActivity {

    int saat,dakika;
    Button tarih;
    EditText etkinlik;
    String event;
    LinearLayout linearLayout;
    FirebaseAuth mAut;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();

    private  static final String shared="textarray[i]";
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarihler);

    etkinlik=(EditText) findViewById(R.id.etkinlik);
    tarih=(Button)findViewById(R.id.tarih);

        Calendar calendar= Calendar.getInstance();
        int gun= calendar.get(Calendar.DAY_OF_MONTH);
        int ay= calendar.get(Calendar.MONTH);
        int yil= calendar.get(Calendar.YEAR);
        mAut= FirebaseAuth.getInstance(); //kimlik doğrulama ekranı bağlantısı oluşturma


      tarih.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if( !TextUtils.isEmpty(etkinlik.getText().toString())){

                    DatePickerDialog datePickerDialog=new DatePickerDialog(tarihler.this, new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {


                            TimePickerDialog timePickerDialog=new TimePickerDialog(tarihler.this , new TimePickerDialog.OnTimeSetListener() {
                                @Override
                                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                                    saat=hourOfDay;
                                    dakika=minute;

                                    Calendar calendar= Calendar.getInstance();
                                    calendar.set(0,0,0,saat,dakika);

                                    event=etkinlik.getText().toString();

                                    String[] textArray = {(dayOfMonth + "/" + month + "/" + year+" "+ DateFormat.format("HH:mm aa",calendar)+" "+event)};
                                    linearLayout=(LinearLayout)findViewById(R.id.lay2);

                                    for( int i = 0; i < textArray.length; i++ )
                                    {
                                        TextView textView = new TextView(tarihler.this);
                                        textView.setTextSize(20);
                                        textView.setText(textArray[i]);
                                        linearLayout.addView(textView);

                                       sharedPreferences= getSharedPreferences(shared,MODE_PRIVATE);

                                        if(!TextUtils.isEmpty(textArray[i])){

                                            myRef.child("tarih").push().setValue(textArray[i]).addOnCompleteListener(tarihler.this, new OnCompleteListener<Void>() { //push methodu sayesinde realtime veritabanına yeni bir alan oluşturup verileri oraya kaydediyor
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if(task.isSuccessful()){

                                                        Toast.makeText(tarihler.this,"başarılı",Toast.LENGTH_LONG).show();
                                                    }else{
                                                        Toast.makeText(tarihler.this,"bir hata ile karşılaşıldı ",Toast.LENGTH_LONG).show();
                                                    }
                                                }
                                            });

                                        }


                                    }

                                }

                            },24,0,true);

                            timePickerDialog.updateTime(saat,dakika);
                            timePickerDialog.show();

                        }
                    },gun,ay,yil);
                    datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis()); //şimdiki zamanı gösteriyor
                    datePickerDialog.show();
                }
                else {
                    Toast.makeText(tarihler.this,"Lütfen boş alan bırakmayınız ",Toast.LENGTH_LONG).show(); //kayıt sırasında bir hata ile karşılaşılırsa bildirim mesajı verir
                }

            }
        });



    }
}