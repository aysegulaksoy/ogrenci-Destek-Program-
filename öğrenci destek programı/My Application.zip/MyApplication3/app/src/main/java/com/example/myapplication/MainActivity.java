package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.TextUtilsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText name, surname, email, password;
    String txtname, txtsurname,txtmail, txtpassword;
    FirebaseAuth mAut; //google ile işlem yapma
    FirebaseFirestore fstore; // bulut tabanlı veritabanına ağlamak için
    DocumentReference df;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=(EditText) findViewById(R.id.name);
        surname=(EditText) findViewById(R.id.surname);
        email= (EditText) findViewById(R.id.editTextTextEmailAddress);
        password=(EditText) findViewById(R.id.editTextTextPassword);


        fstore= FirebaseFirestore.getInstance(); //bulut veritabanı bağlantısı oluşturma
        mAut= FirebaseAuth.getInstance(); //kimlik doğrulama ekranı bağlantısı oluşturma

    }
    public void save(View v){

        //edittext verilerini stringe çevirme
        txtmail= email.getText().toString();
        txtpassword= password.getText().toString();
        txtname= name.getText().toString();
        txtsurname= surname.getText().toString();

        if(!TextUtils.isEmpty(txtname)&&!TextUtils.isEmpty(txtsurname)&&!TextUtils.isEmpty(txtmail)&&!TextUtils.isEmpty(txtpassword)){ //edittextlerin boş olup olmadığını kontrol etme

       mAut.createUserWithEmailAndPassword(txtmail,txtpassword).addOnSuccessListener(new OnSuccessListener<AuthResult>() {  //mail ve şifre ile bir veritabanı oluşturma
           @Override
           public void onSuccess(AuthResult authResult) {


               FirebaseUser user= mAut.getCurrentUser();

               Toast.makeText(MainActivity.this,"başarılı",Toast.LENGTH_LONG).show(); //kayıt işlemi başarılı ise bildirim gönderir

               df= fstore.collection("users").document(user.getUid()); //veritabanında users adında bir alan oluşturur

               Map<String,Object> userinfo= new HashMap<>(); // verilerin users alanına kaydedilebilmesi için gereklidir
               userinfo.put("Ad", txtname); //veri tabanında ad adında bir alan oluşturup txtname edittextine yazılanı kaydeder
               userinfo.put("Soyad", txtsurname);//veri tabanında soyad adında bir alan oluşturup txtsurname edittextine yazılanı kaydeder
               userinfo.put("Mail", txtmail);//veri tabanında email adında bir alan oluşturup txtmail edittextine yazılanı kaydeder
               userinfo.put("Şifre",txtpassword);//veri tabanında şifre adında bir alan oluşturup txtpassword edittextine yazılanı kaydeder
               df.set(userinfo);

               startActivity(new Intent(getApplicationContext(),MainActivity.class));
               finish();
           }
       }).addOnFailureListener(new OnFailureListener() {
           @Override
           public void onFailure(@NonNull  Exception e) {

               Toast.makeText(MainActivity.this,"bir hata ile karşılaşıldı ",Toast.LENGTH_LONG).show(); //kayıt sırasında bir hata ile karşılaşılırsa bildirim mesajı verir

           }
       });



        }
    }

    public void giris(View v){

        Intent i= new Intent(getApplicationContext(),giris.class); //giris ekranına yönlendirir
        startActivity(i);

    }
}






           /*
            // realtime database işlemleri


            myRef.child("ad").setValue(txtname).addOnCompleteListener(this, new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){

                        Toast.makeText(MainActivity.this,"başarılı",Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(MainActivity.this,"bir hata ile karşılaşıldı ",Toast.LENGTH_LONG).show();
                    }
                }
            });
            myRef.child("soyad").setValue(txtsurname).addOnCompleteListener(this, new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){

                        Toast.makeText(MainActivity.this,"başarılı",Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(MainActivity.this,"bir hata ile karşılaşıldı ",Toast.LENGTH_LONG).show();
                    }
                }
            });
            myRef.child("mail").setValue(txtmail).addOnCompleteListener(this, new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){

                        Toast.makeText(MainActivity.this,"başarılı",Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(MainActivity.this,"bir hata ile karşılaşıldı ",Toast.LENGTH_LONG).show();
                    }
                }
            });
            myRef.child("sifre").setValue(txtpassword).addOnCompleteListener(this, new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){

                        Toast.makeText(MainActivity.this,"başarılı",Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(MainActivity.this,"bir hata ile karşılaşıldı ",Toast.LENGTH_LONG).show();
                    }
                }
            });




*/